package com.green.DataPractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataPracticeApplication.class, args);
	}

}
