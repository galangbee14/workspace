package com.green.DataPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
